# Lab 7 — Knowledge Distillation Report

**Student:** Alexander ZAINOUN

---
## Part 1: Conceptual Questions

**Q1: Why do we divide logits by temperature before applying softmax? What happens when $T \to \infty$?**

> *(no answer)*

**Q2: Why do we multiply the KL divergence by $T^2$?**

> *(no answer)*

---
## Scenario A: Capacity Mismatch

![scenario_a_capacity](plots/scenario_a_capacity.pdf)

![scenario_a_curves](plots/scenario_a_curves.pdf)

**Q3: Which student benefited most from distillation? Which benefited least? Why?**

> *(no answer)*

**Q4: What does this tell us about the relationship between student capacity and distillation effectiveness?**

> *(no answer)*

---
## Scenario B: Imbalanced Data Bias

![scenario_b_confusion](plots/scenario_b_confusion.pdf)

![scenario_b_f1](plots/scenario_b_f1.pdf)

**Q5: Compare per-class F1 scores. Which classes suffer most? Are these the minority classes?**

> *(no answer)*

**Q6: Did distillation help or hurt on minority classes compared to standalone training? What mechanism explains this?**

> *(no answer)*

---
## Scenario C: Temperature Sensitivity

![scenario_c_temperature](plots/scenario_c_temperature.pdf)

![scenario_c_softmax](plots/scenario_c_softmax.pdf)

**Q7: What is the optimal temperature range? Why does performance degrade at the extremes?**

> *(no answer)*

**Q8: Look at the softmax visualizations. At $T=20$, what does the distribution look like? Why is this problematic for learning?**

> *(no answer)*

---
## Synthesis

**S1: Under what conditions did distillation clearly help?**

> *(no answer)*

**S2: Under what conditions did distillation fail or hurt?**

> *(no answer)*

**S3: Practical guidelines for knowledge distillation in production.**

> *(no answer)*

**S4: Propose one modification to address a failure case you observed.**

> *(no answer)*
